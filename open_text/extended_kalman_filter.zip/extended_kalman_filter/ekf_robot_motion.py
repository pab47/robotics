#ensure that the data files 
#(time.txt, state.txt, control.txt, measurement.txt) 
# are in the same folder as this script before running. 
import os
import numpy as np
from matplotlib import pyplot as plt

class parameters:
    def __init__(self):
        #parameters for estimation
        self.Q = (0.1**2)*np.diag([0.02,0.02,0.1])
        self.R = np.diag([0.1,0.1])

        #initialization for the filter
        self.x_hat = np.array([0.0,0.0,0.0])
        self.P = np.diag([0.01,0.01,10])
    
        #parameters for obstacle
        self.x_loc = np.array([0, 0])
        self.y_loc = np.array([-2, -1])

def f(X,U,dt):
    x = X[0]
    y = X[1]
    theta = X[2]
    v = U[0]
    omega = U[1]

    return np.array([x+v*np.cos(theta)*dt,y+v*np.sin(theta)*dt,theta+omega*dt])

def dfdx(X,U,dt):
    theta = X[2]
    v = U[0]

    F = np.array([
                [1,0,-v*np.sin(theta)*dt],
                [0,1,v*np.cos(theta)*dt],
                [0,0,1]
                ])

    return F

def dhdx(X,U,dt):
    H = np.array([[1,0,0],[0,1,0]]) #here H = dhdx is a constant
    return H

def main():

    ## Load data files (need to be in the same folder as this script)
    timefilename = "time.txt" #time
    statefilename = "state.txt" #x,y,theta (actual trajectory)
    controlfilename = "control.txt" #v,omega
    measurementfilename = "measurement.txt" #x,y (noisy)
    dirname = os.path.dirname(__file__)
    abspath = os.path.join(dirname + "/" + controlfilename)
    u_all = np.loadtxt(abspath)
    abspath = os.path.join(dirname + "/" + measurementfilename)
    y_all = np.loadtxt(abspath)
    abspath = os.path.join(dirname + "/" + timefilename)
    t_all = np.loadtxt(abspath)
    abspath = os.path.join(dirname + "/" + statefilename) 
    z_all = np.loadtxt(abspath)

    #Get parameters
    parms = parameters()
    x_hat,P = parms.x_hat, parms.P #initialization for estimation
    Q,R = parms.Q, parms.R #filter parameters
    x_loc,y_loc = parms.x_loc, parms.y_loc #location of obstacle
    
    #Initialization
    dt = t_all[1]-t_all[0]
    N = len(t_all)
    shape = (N,3)
    x_all = np.zeros(shape)
    x_all[0,0] = x_hat[0]
    x_all[0,1] = x_hat[1]
    x_all[0,2] = x_hat[2]

    #Extended Kalman Filter loop
    for i in range(0,N-1):
        z = np.array([y_all[i,0],y_all[i,1]])
        u = np.array([u_all[i,0],u_all[i,1]])
        F = dfdx(x_hat,u,dt)

        #Prediction step: state / covariance
        x_hat_minus = f(x_hat, u, dt)
        F = dfdx(x_hat_minus,u,dt)
        P_minus = F @ P @ F.T + Q

        # Update step: Gain / state / covariance
        H = dhdx(x_hat_minus,u,dt)
        K = P_minus @ H.T @ np.linalg.inv(H @ P_minus @ H.T + R)
        x_hat = x_hat_minus + K @ (z - H @ x_hat_minus)
        P = (np.eye(len(x_hat)) - K @ H) @ P_minus

        x_all[i+1,0] = x_hat[0]
        x_all[i+1,1] = x_hat[1]
        x_all[i+1,2] = x_hat[2]

    #Plot the results
    plt.figure(1)
    plt.plot(y_all[:,0],y_all[:,1],'k',alpha=0.2) #measured
    plt.plot(z_all[:,0],z_all[:,1],'g',linewidth=3,alpha=0.5); #actual trajectory
    plt.plot(x_all[:,0],x_all[:,1],'r-.')#estimated trajectory  
    plt.plot(x_loc,y_loc,color='black',linewidth=5)
    plt.legend(['measured','actual','estimated'])
    plt.grid()
    plt.ylabel("y position",fontsize=16)
    plt.xlabel("x position",fontsize=16)
    plt.gca().set_aspect('equal')
    plt.show()

if __name__ == "__main__":
    main()


