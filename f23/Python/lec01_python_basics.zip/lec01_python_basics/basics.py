# a = 1
# b = 2
# c = a + b
# print(c)
# print(type(c))

#list
# list = [1,"Hello",23,"Test"]
# print(list)
# # print(list[0])
# # print(list[1])
# list.append("new variable")
# print(list)

#if-else
# c = 11
# if c>0 and c<=5:
#     print("C is between 0 and 5")
# elif (c>5 and c<9):
#     print("c is between 5 and 9")
# else:
#     print("c is greater than or equal to 10")
    
#while
# i = 1
# while i<10:
#     print(i)
#     if (i==6):
#         break;
#     i +=1
    
# print("\n")
# for x in range(5):
#     print(x)
    
def my_add(a,b):
    return a+b

print(my_add(1,2))
