import sympy as sy

x,xdot,xddot  = sy.symbols('x xdot xddot', real=True) 

# f1 = cos(x), where x = x(t)
f1 = sy.sin(x)
df1dt = sy.diff(f1,x)*xdot
print('f1(x(t))')
print(f1)
print(' ')
print('df1dt');
print(df1dt)

print(' ')
#f2 = x*xdot where x = x(t)
f2 = x*xdot
print('f2(x(t))')
print(f2)
print(' ')
df2dt = sy.diff(f2,x)*xdot + sy.diff(f2,xdot)*xddot
print('df2dt')
print(df2dt)
