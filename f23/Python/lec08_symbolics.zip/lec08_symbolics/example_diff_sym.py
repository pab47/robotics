import sympy as sy

x  = sy.symbols('x', real=True) # defining the variables
f0 = x**2+2*x+1
print('f(x)')
print(f0)
df0dx = sy.diff(f0,x) # Gives the first derivative of the function

print(' ')
print('df(x)/dx')
print(df0dx)

print(' ')
print('df(x=1)/dx')
xval = 1
print(df0dx.subs(x,xval))
