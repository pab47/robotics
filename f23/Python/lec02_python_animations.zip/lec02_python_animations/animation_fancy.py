import numpy as np
import matplotlib.pyplot as plt

fig = plt.figure()
ax = fig.add_subplot(1,1,1)

y1 = np.linspace(0.5,1.5,30)
y2 = np.linspace(1.5,0.5,40)
y = np.concatenate((y1,y2))

patch_rectangle = plt.Rectangle((0,0),2,1,\
                            color='brown',alpha=1)


patch_line = plt.Line2D([0,2],[1,1],linewidth=5,\
                        color="black")


for i in range(len(y)):
    
    patch_circle = plt.Circle((1,y[i]),radius=0.25,color='yellow')
    ax.add_patch(patch_circle)
    ax.add_patch(patch_rectangle)
    ax.add_line(patch_line)

    plt.xlim(0,2)
    plt.ylim(0,2)
    plt.gca().set_aspect('equal')
    
    plt.pause(0.2)
    patch_circle.remove()

plt.pause(2)
plt.close()