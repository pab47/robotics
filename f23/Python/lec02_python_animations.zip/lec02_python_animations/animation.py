import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0,6,100)
y = np.cos(t)

plt.figure(1)
plt.plot(t,y,'r')

for i in range(len(t)):
    tmp, = plt.plot(t[i],y[i],color="green",\
             marker='o',markersize=10)
    plt.pause(0.02)
    tmp.remove();

plt.close()