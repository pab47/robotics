import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0,6,50)
y1 = np.sin(t)
y2 = np.cos(t)

plt.figure(1)
plt.plot(t,y1,'r')
plt.plot(t,y2,'b-.');
plt.legend(['sin','cos'])
plt.xlabel('t');
plt.ylabel("y");
plt.title("plot of sin/cos as a function of t")
plt.pause(2)
plt.close()

plt.figure(2)
#write code here
plt.plot(t,y1,'r')
plt.pause(2)
plt.close()