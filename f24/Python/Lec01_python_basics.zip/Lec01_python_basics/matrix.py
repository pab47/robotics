import numpy as np

#A = [2 4; 5 -6]; #matlab does not work
A = np.array([
    [2,4],
    [5,-6]
])
print(A)

b = np.array([1,2])
print(b)

B = A.dot(b)
print(B)

print(A.transpose())

Ainv = np.linalg.inv(A)
print(Ainv)

print(np.matmul(Ainv,A))

I = np.identity(4)
print(I)


