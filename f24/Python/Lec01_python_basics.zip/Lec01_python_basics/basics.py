import numpy as np
#print("Hello")

list = [1, "hello", "test",23]
print(list[0])

#if-else
c = 10
if (c>0 and c<5):
    print("c is between 0 and 5")
else:
    print("c is greater than 5")

c = 10

while True:
    if c > 0 and c < 5:
        print("c is between 0 and 5")
    else:
        print("c is greater than 5")
    break  # Exit the loop after the first check

def my_function():
    print("Hello from function")

def my_add(a,b):
    sum = a+b
    return sum

my_function()

sum = my_add(1,2)
print(sum)
print(np.add(1,2))
