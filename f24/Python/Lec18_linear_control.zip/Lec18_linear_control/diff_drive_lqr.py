import numpy as np
import control

class parameters:
    def __init__(self):

        self.theta = 0
        self.v = 0.2
        self.w = 0.1

        self.pause = 0.01
        self.fps =20

def sin(theta):
    return np.sin(theta)

def cos(theta):
    return np.cos(theta)

parms = parameters()
theta = parms.theta
v = parms.v
w = parms.w

A = np.array([
            [0,0,-v*sin(theta)],
            [0,0,v*cos(theta)],
            [0,0,0]
            ])

B = np.array([
             [cos(theta),0],
             [sin(theta),0],
             [0, 1]
             ])

#compute eigenvalues of uncontrolled system
eigVal,eigVec = np.linalg.eig(A)
print('eig-vals (uncontrolled)=',eigVal) #eigvalues on imaginary axis

# #compute controllability of system
Co = control.ctrb(A, B)
print('rank=',np.linalg.matrix_rank(Co))

# #pole plaecement
print('\nPole placement');
p = np.array([-1,-2,-3])
K = control.place(A,B,p)
print("K = ",K)
eigVal,eigVec = np.linalg.eig(np.subtract(A,np.matmul(B,K)))
print('eig-vals (controlled)=',eigVal)

#create lqr controller
print('\nLQR');
Q = np.eye((3))
R = 1e-2*np.eye((2));
K, S, E = control.lqr(A,B,Q,R)
print('K=',K)
print('eig-vals (controlled)=',E) #eigvalues are negative
#manually checking eigenvalues
# eigVal,eigVec = np.linalg.eig(np.subtract(A,np.matmul(B,K)))
# print('eig-vals (controlled)=',eigVal)
