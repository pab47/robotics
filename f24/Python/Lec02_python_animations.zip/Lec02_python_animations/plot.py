import numpy as np
import matplotlib.pyplot as plt

# Define the interval
x = np.linspace(0, 2 * np.pi, 100)  # 1000 points between 0 and 2*pi

# Calculate sin(x)
y = np.sin(x)

# Plot the graph
plt.plot(x, y, label='sin(x)')

# Add labels and title
plt.xlabel('x')
plt.ylabel('sin(x)')
plt.title('Plot of sin(x) from 0 to 2π')

plt.show(block=False)  # Show the plot without blocking the execution

# Pause for 4 seconds
plt.pause(4)

# Close the plot window
plt.close()
