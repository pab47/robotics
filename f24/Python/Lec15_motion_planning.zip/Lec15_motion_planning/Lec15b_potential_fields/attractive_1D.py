import numpy as np
import matplotlib.pyplot as plt

X = np.linspace(0,10)
xf = 5 #goal
xi = 10 #constant

# Quadratic potential
U_att1 = 0.5 * xi * ((X - xf) ** 2)

# Conic potential
U_att2 = xi * np.sqrt((X - xf) ** 2)

plt.figure()
plt.subplot(2,1,1)
plt.plot(X,U_att1,color='red')
plt.ylabel('quadratic')
plt.subplot(2,1,2)
plt.plot(X,U_att2,color='blue')
plt.ylabel('conic')
plt.show()
