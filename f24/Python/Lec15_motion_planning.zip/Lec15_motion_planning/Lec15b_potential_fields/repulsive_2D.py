import numpy as np
import matplotlib.pyplot as plt

# Create meshgrid
X, Y = np.meshgrid(np.arange(-1, 1., 0.01), np.arange(-1, 1.0, 0.01))

bx = 0
by = 0
rho_0 = 1
U_rep_max = 10
eta = 10

rho = np.sqrt((X - bx) ** 2 + (Y - by) ** 2)

m, n = rho.shape
U_rep = np.zeros((m, n))
for i in range(m):
    for j in range(n):
        if rho[i, j] < rho_0:
            U_rep[i, j] = 0.5 * eta * (((1 / rho[i, j]) - 1 / rho_0) ** 2)
            if U_rep[i, j] > U_rep_max:
                U_rep[i, j] = U_rep_max

# Plot U_rep as a surface
fig1 = plt.figure(1)
ax1 = plt.axes(projection='3d')
ax1.plot_surface(X, Y, U_rep)
#ax1.axis('equal')

# Plot contour of U_rep
fig2 = plt.figure(2)
ax2 = plt.axes(projection='3d')
contour_filled = ax2.contourf(X, Y, U_rep, levels=15, cmap='viridis')
ax2.plot(bx, by, 'ro', markersize=10)
ax2.grid(True)
ax2.view_init(elev=90, azim=0) # Set the view to look from the top (x-y view)
fig2.colorbar(contour_filled, ax=ax2, label='Contour Levels') # Add a colorbar to indicate the contour levels


# Display both figures
plt.show()
