import numpy as np
import matplotlib.pyplot as plt

X = np.linspace(0,10)
bx = 5 #center
rho_0 = 2; #radius of obstacle
eta = 10 #constant
U_rep_max = 1;

U_rep = np.array([])
for i in range(0,len(X)):
    rho = np.sqrt( (X[i]-bx)**2);
    if rho>rho_0:
        U_tmp = 0;
    else:
        U_tmp = 0.5*eta*((1/rho) - (1/rho_0))**2
        if (U_tmp>U_rep_max):
            U_tmp = U_rep_max;
    U_rep = np.append(U_rep,U_tmp)


plt.figure()
plt.plot(X,U_rep,color='red')
plt.ylabel('quadratic')
plt.show()
