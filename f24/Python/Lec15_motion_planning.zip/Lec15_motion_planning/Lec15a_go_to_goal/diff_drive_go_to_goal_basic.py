from matplotlib import pyplot as plt
from scipy import interpolate
import random
import math
import numpy as np

obstacles_on = 1;

class parameters:
    def __init__(self):
        self.dt = 0.1; #integration step
        self.goal = np.array([1.5,1.5]);
        self.obstacles = np.array([
        [1,1,0.2]
        ]); #x,y,R
        self.v = 0.2; #nominal speed
        self.K = 5 #gain for turning
        self.r0 = 0.1; #when the robot is at this distance from goal then stop
        self.R = 0.1; #radius of the robot
        self.r_buffer = self.R; #extra distance to start turning
        self.v_max = 0.5; #max speed
        self.pause = 0.001
        self.fps = 10

def animate(t,z,parms):

    t_interp = np.arange(t[0],t[len(t)-1],1/parms.fps)
    [m,n] = np.shape(z)
    shape = (len(t_interp),n)
    z_interp = np.zeros(shape)

    for i in range(0,n):
        f = interpolate.interp1d(t, z[:,i])
        z_interp[:,i] = f(t_interp)

    R = parms.R;
    phi = np.arange(0,2*np.pi,0.1)

    x_goal = parms.goal[0]
    y_goal = parms.goal[1]

    n_obstacles,n = parms.obstacles.shape

    for i in range(0,len(t_interp)):
        x = z_interp[i,0]
        y = z_interp[i,1]
        theta = z_interp[i,2]

        x_robot = x + R*np.cos(phi)
        y_robot = y + R*np.sin(phi)

        x2 = x + R*np.cos(theta)
        y2 = y + R*np.sin(theta)

        line, = plt.plot([x, x2],[y, y2],color="black")
        robot,  = plt.plot(x_robot,y_robot,color='black')
        shape, = plt.plot(z_interp[0:i,0],z_interp[0:i,1],color='blue');
        goal,  = plt.plot(x_goal, y_goal, 'ko', markersize=10, markerfacecolor='black')

        if (obstacles_on==1):
            for i in range(0,n_obstacles):
                x_center_obs = parms.obstacles[i,0];
                y_center_obs = parms.obstacles[i,1];
                r_obs = parms.obstacles[i,2];

                x_obs = x_center_obs + r_obs*np.cos(phi)
                y_obs = y_center_obs + r_obs*np.sin(phi)

                plt.plot(x_obs,y_obs,color='red')

        plt.xlim(-2,2)
        plt.ylim(-2,2)
        plt.gca().set_aspect('equal')
        plt.pause(parms.pause)
        line.remove()
        robot.remove()
        shape.remove()

plt.close()


def euler_integration(tspan,z0,u,parms):
    v = u[0]

    v_max = parms.v_max;
    if (v>=v_max):
        v = v_max;

    omega = u[1]
    h = tspan[1]-tspan[0]

    x0 = z0[0]
    y0 = z0[1]
    theta0 = z0[2]

    xdot_c = v*math.cos(theta0)
    ydot_c = v*math.sin(theta0)
    thetadot = omega

    x1 = x0 + xdot_c*h
    y1 = y0 + ydot_c*h
    theta1 = theta0 + thetadot*h

    z1 = [x1, y1, theta1]
    return z1

parms = parameters()
direction = random.choice([-1, 1]) #randomly generate a direction to turn in the beginnig

#initial condition, [x0, y0, theta0]
z0 = [0, 0, 0]

N = 500 #end time
h = parms.dt
x_goal = parms.goal[0]
y_goal = parms.goal[1]
r0 = parms.r0
# %%%%% the controls are v = speed and omega = direction
# %%%%%% v = 0.5r(phidot_r + phidot_l)
# %%%%%% omega = 0.5 (r/b)*(phitdot_r - phidot_l)
z = np.array([z0]);
t = np.array([0]);

for i in range(0,N):

    x = z0[0]; y = z0[1]; theta = z0[2];
    theta_des = np.arctan2( y_goal - y,x_goal - x);

    v = parms.v;

    if (obstacles_on==1):
        n_obstacles,n = parms.obstacles.shape
        for i in range(0,n_obstacles):
            x_obs = parms.obstacles[i,0]
            y_obs = parms.obstacles[i,1]
            r_obs = parms.obstacles[i,2] + parms.r_buffer
            dist_obstacle = np.sqrt(  (x_obs - x)**2 + (y_obs - y)**2 ) - r_obs
            if (dist_obstacle < 0): #if the car get too close, change the direction
                theta_des = np.arctan2( y_obs - y,x_obs - x) + direction*np.pi/2;

    omega = parms.K*(theta_des - theta);

    r = np.sqrt((x_goal - x)**2 + (y_goal - y)**2)
    if (r < r0):
        v = 0 #come to stop
        break; #exit for loop

    z0 = euler_integration([0, h],z0,[v,omega],parms)
    z = np.vstack([z, z0])
    t = np.append(t,t[-1]+h)

animate(t,z,parms)
