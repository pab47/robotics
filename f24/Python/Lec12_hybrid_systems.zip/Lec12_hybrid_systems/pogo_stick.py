from matplotlib import pyplot as plt
import numpy as np
import math
from scipy import interpolate
from scipy.integrate import odeint
from scipy.integrate import solve_ivp
from scipy.optimize import fsolve

class parameters:
    def __init__(self):
        self.g = 10
        self.m = 1
        self.l0 = 1
        self.k1 = 500 #going down in stance phase
        self.k2 = 500 #going up in stance phase
        self.theta = 0 #step angle
        self.pause = 0.01
        self.fps = 30

def sin(angle):
    return np.sin(angle)

def cos(angle):
    return np.cos(angle)

def animate(t,z,parms):
    #interpolation
    data_pts = 1/parms.fps
    t_interp = np.arange(t[0],t[len(t)-1],data_pts)
    [m,n] = np.shape(z)
    shape = (len(t_interp),n)
    z_interp = np.zeros(shape)

    for i in range(0,n):
        f = interpolate.interp1d(t, z[:,i])
        z_interp[:,i] = f(t_interp)

    l0 = parms.l0

    min_xh = min(z[:,4]); max_xh = max(z[:,4]);
    min_yh = -0.1; max_yh = max(1.9*l0,max(z[:,2]))
    dist_travelled = max_xh - min_xh
    camera_rate = dist_travelled/len(t_interp);

    window_xmin = -1*l0; window_xmax = 1*l0;
    window_ymin = min_yh; window_ymax = max_yh;

    R1 = np.array([min_xh-l0,0])
    R2 = np.array([max_xh+l0,0])

    ramp, = plt.plot([R1[0], R2[0]],[R1[1], R2[1]],linewidth=5, color='black')
    #plot
    for i in range(0,len(t_interp)):

        xh = z_interp[i,0];
        yh = z_interp[i,2];
        xf = z_interp[i,4];
        yf = z_interp[i,5];

        H = np.array([xh, yh])
        F = np.array([xf, yf])

        hip, = plt.plot(H[0],H[1],color='red',marker='o',markersize=20)
        leg, = plt.plot([H[0], F[0]],[H[1], F[1]],linewidth=5, color=np.array([0,0.8,0]))

        window_xmin = window_xmin + camera_rate;
        window_xmax = window_xmax + camera_rate;
        plt.xlim(window_xmin,window_xmax)
        plt.ylim(window_ymin,window_ymax)
        plt.gca().set_aspect('equal')

        plt.pause(parms.pause)
        hip.remove()
        leg.remove()

    plt.close()

def one_step(z0,steps,parms):

    l0 = parms.l0
    theta = parms.theta

    x0 = z0[0]
    x0dot = z0[1];
    y0 = z0[2];
    y0dot = z0[3];

    #apex to the ground
    t0 = 0

    z0 = np.array([x0, x0dot, y0, y0dot])
    xf = x0+l0*sin(theta)
    yf = y0-l0*cos(theta)

    zz = np.append(z0,np.array([xf,yf]));
    tt = t0

    for ii in range(0,steps):
        tf = t0+5;
        t = np.linspace(t0, tf, 1001)
        contact.terminal = True
        contact.direction = -1
        sol1 = solve_ivp(flight,[t0, tf],z0,method='RK45', t_eval=t, dense_output=True, \
                        events=contact, atol = 1e-13,rtol = 1e-12, \
                        args=(parms.m,parms.l0,parms.g,parms.k1,parms.k2,parms.theta))

        #1a) sol1.t and sol1.y has solution from t0 to a little before the event
        [m,n] = np.shape(sol1.y) #m=4, n=35 eg
        shape = (n,m+2)
        t1 = sol1.t #t excludes the value at the event t<t_events
        z1 = np.zeros(shape)

        # save data in z
        for i in range(0,m):
            z1[:,i] = sol1.y[i,:]
        z1[:,m] = z1[:,0] + l0*sin(theta)
        z1[:,m+1] = z1[:,2] - l0*cos(theta)

        #1b) get t, y from sol.y_events and exact time sol.t_events
        [mm,nn,pp] = np.shape(sol1.y_events)
        tt_last_event = sol1.t_events[mm-1]
        yy_last_event = sol1.y_events[mm-1]

        t0 = tt_last_event[0]
        x0 = yy_last_event[0,0]
        x_com = x0; #save x0
        x0 = -l0*sin(theta)
        x_foot_stance = x_com + l0*sin(theta)
        y_foot_stance = 0
        x0dot = yy_last_event[0,1]

        y0 = yy_last_event[0,2]
        y0dot = yy_last_event[0,3]
        z0 = np.array([x0, x0dot, y0, y0dot])

        #stance phase
        tf = t0+5
        t = np.linspace(t0, tf, 1001)
        release.terminal = True
        release.direction = 1
        sol2 = solve_ivp(stance,[t0, tf],z0,method='RK45', t_eval=t, dense_output=True, \
                        events=release, atol = 1e-13,rtol = 1e-12, \
                        args=(parms.m,parms.l0,parms.g,parms.k1,parms.k2,parms.theta))

        #2a) sol1.t and sol1.y has solution from t0 to a little before the event
        [m,n] = np.shape(sol2.y) #m=4, n=35 eg
        shape = (n,m+2)
        t2 = sol2.t #t excludes the value at the event t<t_events
        z2 = np.zeros(shape)

        # save data in z
        for i in range(0,m):
            if i==0:
                z2[:,i] = sol2.y[i,:]+x_com+l0*sin(theta)
            else:
                z2[:,i] = sol2.y[i,:]
        z2[:,m] = x_foot_stance
        z2[:,m+1] = y_foot_stance

        #2b) get t, y from sol.y_events and exact time sol.t_events
        [mm,nn,pp] = np.shape(sol2.y_events)
        tt_last_event = sol2.t_events[mm-1]
        yy_last_event = sol2.y_events[mm-1]

        t0 = tt_last_event[0]
        x0 = yy_last_event[0,0]+x_com+l0*sin(theta)
        x0dot = yy_last_event[0,1]
        y0 = yy_last_event[0,2]
        y0dot = yy_last_event[0,3]
        z0 = np.array([x0, x0dot, y0, y0dot])

        #stance to apex phase
        tf = t0+5
        t = np.linspace(t0, tf, 1001)
        apex.terminal = True
        apex.direction = -1
        sol3 = solve_ivp(flight,[t0, tf],z0,method='RK45', t_eval=t, dense_output=True, \
                        events=apex, atol = 1e-13,rtol = 1e-12, \
                        args=(parms.m,parms.l0,parms.g,parms.k1,parms.k2,parms.theta))

        #3a) sol1.t and sol1.y has solution from t0 to a little before the event
        [m,n] = np.shape(sol3.y) #m=4, n=35 eg
        shape = (n,m+2)
        t3 = sol3.t #t excludes the value at the event t<t_events
        z3 = np.zeros(shape)

        # save data in z
        for i in range(0,m):
                z3[:,i] = sol3.y[i,:]
        z3[:,m] = z3[:,0] + l0*sin(theta)
        z3[:,m+1] = z3[:,2] - l0*cos(theta)

        #3b) get t, y from sol.y_events and exact time sol.t_events
        [mm,nn,pp] = np.shape(sol3.y_events)
        tt_last_event = sol3.t_events[mm-1]
        yy_last_event = sol3.y_events[mm-1]


        t0 = tt_last_event[0]
        x0 = yy_last_event[0,0]
        x0dot = yy_last_event[0,1]
        y0 = yy_last_event[0,2]
        y0dot = yy_last_event[0,3]
        z0 = np.array([x0, x0dot, y0, y0dot])
        zf = np.array([x0dot,y0])

        [mm1,nn] = np.shape(z1)
        [mm2,nn] = np.shape(z2)
        [mm3,nn] = np.shape(z3)
        if (ii==0):
            tt = np.concatenate(([tt], t1[1:mm1-1],t2[1:mm2-1],t3[1:mm3-1]), axis=0)
            zz = np.concatenate(([zz], z1[1:mm1-1,:],z2[1:mm2-1,:],z3[1:mm3-1,:]), axis=0)
        else:
            tt = np.concatenate((tt, t1[1:mm1-1],t2[1:mm2-1],t3[1:mm3-1]), axis=0)
            zz = np.concatenate((zz, z1[1:mm1-1,:],z2[1:mm2-1,:],z3[1:mm3-1,:]), axis=0)

    return zz,tt,zf

def release(t, z, m,l0,g,k1,k2,theta):

    x,xdot,y,ydot = z
    l = math.sqrt(x**2+y**2)
    gstop = l-l0
    return gstop

def contact(t, z, m,l0,g,k1,k2,theta):

    x,xdot,y,ydot = z
    gstop = y - l0*cos(theta)
    return gstop

def apex(t, z, m,l0,g,k1,k2,theta):

    x,xdot,y,ydot = z
    gstop = ydot - 0
    return gstop

def flight(t,z,m,l0,g,k1,k2,theta):
    x,xdot,y,ydot = z

    return [xdot, 0, ydot, -g]

def controller (ydot,k1,k2):
    if (ydot<0): #going down
        k = k1;
    else:        #going up
        k = k2

    return k;

def stance(t,z,m,l0,g,k1,k2,theta):
    x,xdot,y,ydot = z

    #k = 0.5*(k1+k2)
    k = controller(ydot,k1,k2)


    l = math.sqrt(x**2+y**2)
    F_spring = k*(l0-l);
    Fx_spring = F_spring*(x/l);
    Fy_spring = F_spring*(y/l);
    Fy_gravity = m*g;
    xddot = (1/m)*Fx_spring;
    yddot = (1/m)*(Fy_spring-Fy_gravity)

    return [xdot, xddot, ydot, yddot]

parms = parameters();

x0 = 0
xdot0 = 0 #forward speed
y0 = 1.2 #height
ydot0 = 0;
z0 = np.array([x0,xdot0,y0,ydot0])

steps = 5
[z,t,zf] = one_step(z0,steps,parms)



animate(t,z,parms)

if (0):
    plt.figure(1)
    plt.subplot(2,1,1)
    plt.plot(t,z[:,0],'r--')
    plt.plot(t,z[:,2],'b')
    plt.ylabel('x,y')
    plt.subplot(2,1,2)
    plt.plot(t,z[:,1],'r--')
    plt.plot(t,z[:,3],'b')
    plt.ylabel('vx,vy')
    plt.xlabel('time')

    plt.figure(2)
    plt.plot(z[:,0],z[:,2],'b')
    plt.ylabel('yh')
    plt.xlabel('xh')

    # plt.show()
    plt.show(block=False)
    plt.pause(3)
    plt.close()
