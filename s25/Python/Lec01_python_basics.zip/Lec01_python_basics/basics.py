import numpy as np

# list = [1, "Hello"]
# print(list)
# print(list[0])
# list.append("test")
# print(list)
# print(list[-1])

c = 10
if (c>0 and c<5):
    print('c is between 0 and 5')
else:
    print('c is greater than 5')
    print(f"c = {c}")

i = 0
while i in range(0,5):
    print(i)
    i += 1

def my_function():
    print("Hello from function")


my_function()

def add(a,b):
    sum = a+b
    return sum

d = add(4,5)
print(d)

d2 = np.add(4,5)
print(d2)