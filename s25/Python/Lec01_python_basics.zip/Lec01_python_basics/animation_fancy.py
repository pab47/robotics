import numpy as np
import matplotlib.pyplot as plt

fig = plt.figure()
ax = fig.add_subplot(1,1,1)

y1 = np.linspace(1.5,0.5,10)
y2 = np.linspace(0.5,1.5,10)
y = np.concatenate((y1,y2))

rect = plt.Rectangle((0,0),2,1,color='brown',zorder = 3)
ax.add_patch(rect)
line = plt.Line2D([0,2],[1,1],linewidth=10,color='black',zorder=3)
ax.add_line(line)

plt.xlim(0,2)
plt.ylim(0,2)

plt.gca().set_aspect('equal')

for i in range(0,len(y)):
    circ = plt.Circle((1,y[i]),radius =0.25,color='yellow',zorder=1)
    ax.add_patch(circ)
    plt.pause(0.1)
    circ.remove()




plt.show()