import numpy as np
import matplotlib.pyplot as plt

def sin(x):
    return np.sin(x)

x = np.linspace(0,2*np.pi,100)

y = sin(x)

plt.plot(x,y)

plt.xlabel('x')
plt.ylabel('y')
plt.title('plot of sin(x)')

#plt.show()
plt.show(block=False)
plt.pause(4)
plt.close()