import numpy as np

#A = [2,4; 5 -6];
A = np.array(
    [
        [2,4],
        [5,-6]
    ]
)
print(A)
print(type(A))
print(np.shape(A))

b = np.array(
    [7,10]
)
print(b)
print(np.shape(b))

c = A.dot(b)
print(c)

print(A)
print(A.transpose())
print(A.T)

Ainv = np.linalg.inv(A)
print(Ainv)

print(np.matmul(A,Ainv))

I = np.identity(4)
print(I)