from forward_kinematics import forward_kinematics
import numpy as np
from robot_data import robot
import random

def inverse_kinematics(q,parms):

    x_ref = parms[0]
    y_ref = parms[1]
    theta_ref = parms[2]

    sol = forward_kinematics(q)
    e = sol.e
    xe = e[0]
    ye = e[1]
    theta = sol.theta
    
    return xe-x_ref, ye-y_ref, theta-theta_ref

    
