from matplotlib import pyplot as plt
#from types import SimpleNamespace

def animate(sol,X_ref=None):

    o = sol.o
    p = sol.p
    q = sol.q
    e = sol.e
    e_left1 = sol.e_left1
    e_left2 = sol.e_left2
    e_right1 = sol.e_right1
    e_right2 = sol.e_right2

    # %Draw line from origin to end of link 1
    plt.plot([o[0], p[0]],[o[1], p[1]],linewidth=5, color='red')

    # %Draw line from end of link 1 to end of link 2
    plt.plot([p[0], q[0]],[p[1], q[1]],linewidth=5, color='blue')

    # %Draw line from end of link 2 to end of link 3
    plt.plot([q[0], e[0]],[q[1], e[1]],linewidth=5, color='green')


    # %Draw line from end of link 2 to end of link 3
    plt.plot([e[0], e_left1[0]],[e[1], e_left1[1]],linewidth=5, color='green')
    plt.plot([e[0], e_right1[0]],[e[1], e_right1[1]],linewidth=5, color='green')
    plt.plot([e_left1[0], e_left2[0]],[e_left1[1], e_left2[1]],linewidth=5, color='green')
    plt.plot([e_right1[0], e_right2[0]],[e_right1[1], e_right2[1]],linewidth=5, color='green')

    if X_ref is not None:
        x_ref = X_ref[0];
        y_ref = X_ref[1];
        plt.plot(x_ref,y_ref,marker='o',markersize=5,color='k')

    plt.xlabel("x")
    plt.ylabel("y")

    plt.xlim(-2,2)
    plt.ylim(-2,2)
    plt.gca().set_aspect('equal')
    # plt.axis('square')

    plt.show(block=False)
    plt.pause(5)
    plt.close()
