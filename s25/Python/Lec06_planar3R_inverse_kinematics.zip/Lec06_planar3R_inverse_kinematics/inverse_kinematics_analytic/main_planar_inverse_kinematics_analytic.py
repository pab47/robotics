import numpy as np
from forward_kinematics import forward_kinematics
from inverse_kinematics import inverse_kinematics_analytic
from scipy.optimize import fsolve
from animate import animate


x_ref = 0.5; y_ref = 0; theta_ref = np.pi/2;
parms = [x_ref, y_ref, theta_ref]
q = inverse_kinematics_analytic(parms)

sol = forward_kinematics(q)

X_ref = np.array([x_ref,y_ref,theta_ref])
animate(sol,X_ref)
