from forward_kinematics import forward_kinematics
import numpy as np
from robot_data import robot
import random

def inverse_kinematics_analytic(parms):

    x_ref = parms[0]
    y_ref = parms[1]
    theta_ref = parms[2]

    # l1 = robot.params.l1
    # l2 = robot.params.l2
    # l3 = robot.params.l3
    l1 = robot.body[2].pos[0]
    l2 = robot.body[3].pos[0]
    l3 = robot.params.end_eff_pos_local[0]

    xp_ref = x_ref - l3*np.cos(theta_ref);
    yp_ref = y_ref - l3*np.sin(theta_ref);

    c2 = (xp_ref**2+yp_ref**2 - l1**2 - l2**2)/ (2*l1*l2);

    #there are two possible solutions, choose one randomly
    random_number = random.random()  # Generates a float between 0 and 1

    if (random_number<0.5):
        s2 = -np.sqrt(1-c2**2)
    else:
        s2 = np.sqrt(1-c2**2)
    theta2 = np.arctan2(s2,c2)

    c1 =  (xp_ref*(l1+l2*c2) + yp_ref*l2*s2) / ((l1+l2*c2)**2+(l2*s2)**2)

    #Method1: using atan2
    s1 = np.sqrt(1-c1**2)
    theta1 = np.arctan2(s1,c1)
    theta3 = theta_ref - theta1  - theta2
    q = np.array([theta1,theta2,theta3])
    sol = forward_kinematics(q)
    error = np.sqrt((x_ref - sol.e[0])**2 + (y_ref - sol.e[1])**2)
    if (error>0.1):
        s1 = -np.sqrt(1-c1**2)
        theta1 = np.arctan2(s1,c1)
        theta3 = theta_ref - theta1  - theta2

    #Method2: usign acos
    # theta1 = np.arccos(c1)
    # theta3 = theta_ref - theta1  - theta2
    # q = np.array([theta1,theta2,theta3])
    # sol = forward_kinematics(q)
    # error = np.sqrt((x_ref - sol.e[0])**2 + (y_ref - sol.e[1])**2)
    # if (error>0.1):
    #     theta1 = -np.arccos(c1)
    #     theta3 = theta_ref - theta1  - theta2


    q = np.array([theta1,theta2,theta3])
    return q
