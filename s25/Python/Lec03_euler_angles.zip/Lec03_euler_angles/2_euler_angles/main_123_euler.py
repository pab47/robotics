import sympy as sy
from rotation import rotation

# Define symbolic variables
phi, theta, psi = sy.symbols('phi theta psi', real=True)

# Compute rotation matrices
Rx = rotation(phi, 1)
Ry = rotation(theta, 2)
Rz = rotation(psi, 3)

# Combined rotation matrix
R = Rx * Ry * Rz
print("Combined Rotation Matrix (R):")
sy.pprint(R)

# Simplify after substituting theta = pi/2 (leads to gimbal lock)
# RR = sy.simplify(R.subs(theta, sy.pi / 2))
# print("\nSimplified Rotation Matrix with theta = pi/2 (RR) (gimball lock)")
# sy.pprint(RR)

# Optional: Convert matrices to LaTeX for visualization
# latex_R = sy.latex(R)
# latex_RR = sy.latex(RR)
# print("\nLaTeX representation of R:")
# print(latex_R)
# print("\nLaTeX representation of RR:")
# print(latex_RR)
