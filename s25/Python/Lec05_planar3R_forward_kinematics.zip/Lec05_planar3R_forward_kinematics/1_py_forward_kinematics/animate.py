from matplotlib import pyplot as plt

def animate(sol):

    o = sol.o
    p = sol.p
    q = sol.q
    e = sol.e


    # %Draw line from origin to end of link 1
    plt.plot([o[0], p[0]],[o[1], p[1]],linewidth=5, color='red')

    # %Draw line from end of link 1 to end of link 2
    plt.plot([p[0], q[0]],[p[1], q[1]],linewidth=5, color='blue')

    # %Draw line from end of link 2 to end of link 3
    plt.plot([q[0], e[0]],[q[1], e[1]],linewidth=5, color='green')

    plt.xlabel("x")
    plt.ylabel("y")

    plt.xlim(-2.5,2.5)
    plt.ylim(-2.5,2.5)
    plt.gca().set_aspect('equal')
    # plt.axis('square')

    plt.show(block=False)
    plt.pause(5)
    plt.close()
