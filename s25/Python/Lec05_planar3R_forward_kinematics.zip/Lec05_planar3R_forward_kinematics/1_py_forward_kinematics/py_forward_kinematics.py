import numpy as np
from forward_kinematics import forward_kinematics
from animate import animate

l1 = 1; l2 = 1; l3 = 0.25

theta1 = np.pi/2; theta2 = -np.pi/2; theta3 = np.pi/2;

q = np.array([theta1,theta2,theta3])
parms = (l1,l2,l3)
sol = forward_kinematics(q,parms)

#print(sol.e)
#print(sol.q)
animate(sol)