#if utility.py is located in random location then set this flag to 1
# and indicate the local path relative this this file in utility_path
utility_nonlocal = 1

if (utility_nonlocal ==1):
    import os
    import sys
    utility_path = '../../../../'
    dirname = os.path.dirname(__file__)
    abspath = os.path.join(dirname + "/" + utility_path)
    sys.path.insert(0,abspath)

import utility as ram
