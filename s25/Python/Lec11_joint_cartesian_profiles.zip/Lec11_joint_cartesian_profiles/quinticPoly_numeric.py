import numpy as np
import matplotlib.pyplot as plt

q0 = 0;
qf = 1.0;
t0 = 0;
tf = 1;

a0 = q0*(-10*t0**2*tf**3 + 5*t0*tf**4 - tf**5)/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5) + qf*(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2)/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5)
a1 = 30*q0*t0**2*tf**2/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5) - 30*qf*t0**2*tf**2/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5)
a2 = q0*(-30*t0**2*tf - 30*t0*tf**2)/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5) + qf*(30*t0**2*tf + 30*t0*tf**2)/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5)
a3 = q0*(10*t0**2 + 40*t0*tf + 10*tf**2)/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5) + qf*(-10*t0**2 - 40*t0*tf - 10*tf**2)/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5)
a4 = q0*(-15*t0 - 15*tf)/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5) + qf*(15*t0 + 15*tf)/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5)
a5 = 6*q0/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5) - 6*qf/(t0**5 - 5*t0**4*tf + 10*t0**3*tf**2 - 10*t0**2*tf**3 + 5*t0*tf**4 - tf**5)

t = np.linspace(t0, tf, 101)
q = a0+a1*t+a2*t**2+a3*t**3+a4*t**4+a5*t**5;
qdot = a1+2*a2*t+3*a3*t**2+4*a4*t**3+5*a5*t**4;
qddot = 2*a2+6*a3*t+12*a4*t**2+20*a5*t**3;

plt.figure(1)
plt.subplot(3, 1, 1)
plt.plot(t,q)
plt.ylabel("q");
plt.subplot(3, 1, 2)
plt.plot(t,qdot)
plt.ylabel('qdot');
plt.subplot(3, 1, 3)
plt.plot(t,qddot)
plt.ylabel('qddot');
#plt.show();
plt.show(block=False)
plt.pause(5)
plt.close()
