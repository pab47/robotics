import numpy as np
import utility as ram
from types import SimpleNamespace
from forward_kinematics import forward_kinematics

def differential_kinematics(q,u):

    _,robot = forward_kinematics(q)

    for i in range(1,len(robot.body)+1):
        joint_axis = robot.body[i].joint_axis;
        ipos = robot.body[i].ipos;
        o =  robot.body[i].o_local;
        R = robot.body[i].R_local.T
        R_global = robot.body[i].H_global[0:3,0:3]

        if (i==1):
            w00 = np.array([ 0, 0, 0])
            v00 = np.array([0,0,0])
            robot.body[i].w_local = R@w00 + u[i-1]*joint_axis;
            robot.body[i].v_local = R@(v00 + ram.vec2skew(w00)@o);
        else:
            robot.body[i].w_local = R@robot.body[i-1].w_local + u[i-1]*joint_axis;
            robot.body[i].v_local = R@(robot.body[i-1].v_local + ram.vec2skew(robot.body[i-1].w_local)@o);

        robot.body[i].v_com_local = robot.body[i].v_local + ram.vec2skew(robot.body[i].w_local)@ipos;

        robot.body[i].w_global = R_global@robot.body[i].w_local;
        robot.body[i].v_global = R_global@robot.body[i].v_local;
        robot.body[i].v_com_global = R_global@robot.body[i].v_com_local;

    end_eff_pos_local = robot.params.end_eff_pos_local
    v_tip_local = robot.body[6].v_local + ram.vec2skew(robot.body[6].w_local)@end_eff_pos_local;
    v_tip_global = robot.body[6].H_global[0:3,0:3]@v_tip_local
    w_tip_global = robot.body[6].w_global

    # Store in a SimpleNamespace
    sol = SimpleNamespace(
        v_tip_global = np.array(v_tip_global),
        w_tip_global = np.array(w_tip_global),
        )

    return robot,sol
