import sympy as sy
from vec2skew import vec2skew

# Define symbolic variables
l1, l2, l3 = sy.symbols('l1 l2 l3', real=True)
theta1, theta2, theta3 = sy.symbols('theta1 theta2 theta3', real=True)
m1, m2, m3, g = sy.symbols('m1 m2 m3 g', real=True)

# Axis vector
n = sy.Matrix([0, 0, 1])

# Identity matrix
R00 = sy.eye(3)

# Define rotation and transformation matrices
R01 = sy.Matrix([
    [sy.cos(theta1), -sy.sin(theta1), 0],
    [sy.sin(theta1), sy.cos(theta1), 0],
    [0, 0, 1]
])
O01 = sy.Matrix([0, 0, 0])
H01 = sy.Matrix.vstack(
    sy.Matrix.hstack(R01, O01),
    sy.Matrix([[0, 0, 0, 1]])
)

R12 = sy.Matrix([
    [sy.cos(theta2), -sy.sin(theta2), 0],
    [sy.sin(theta2), sy.cos(theta2), 0],
    [0, 0, 1]
])
O12 = sy.Matrix([l1, 0, 0])
H12 = sy.Matrix.vstack(
    sy.Matrix.hstack(R12, O12),
    sy.Matrix([[0, 0, 0, 1]])
)

R23 = sy.Matrix([
    [sy.cos(theta3), -sy.sin(theta3), 0],
    [sy.sin(theta3), sy.cos(theta3), 0],
    [0, 0, 1]
])
O23 = sy.Matrix([l2, 0, 0])
H23 = sy.Matrix.vstack(
    sy.Matrix.hstack(R23, O23),
    sy.Matrix([[0, 0, 0, 1]])
)

# Compute intermediate transformation matrices
H02 = sy.simplify(H01 * H12)
H03 = sy.simplify(H02 * H23)

R02 = H02[:3, :3]
R03 = H03[:3, :3]

O02 = H02 * sy.Matrix([0, 0, 0, 1])
O03 = H03 * sy.Matrix([0, 0, 0, 1])

# Compute centers of mass
G1 = H01 * sy.Matrix([l1 / 2, 0, 0, 1])
G2 = H02 * sy.Matrix([l2 / 2, 0, 0, 1])
G3 = H03 * sy.Matrix([l3 / 2, 0, 0, 1])

o01 = sy.Matrix(O01)
o02 = sy.Matrix(O02[:3])
o03 = sy.Matrix(O03[:3])
g1 = sy.Matrix(G1[:3])
g2 = sy.Matrix(G2[:3])
g3 = sy.Matrix(G3[:3])

# Torque calculation
Jv_g1 = sy.Matrix.hstack(
    vec2skew(R00 * n) * (g1 - o01),
    sy.zeros(3, 1),
    sy.zeros(3, 1)
)

Jv_g2 = sy.Matrix.hstack(
    vec2skew(R00 * n) * (g2 - o01),
    vec2skew(R01 * n) * (g2 - o02),
    sy.zeros(3, 1)
)

Jv_g3 = sy.Matrix.hstack(
    vec2skew(R00 * n) * (g3 - o01),
    vec2skew(R01 * n) * (g3 - o02),
    vec2skew(R02 * n) * (g3 - o03)
)

# Gravitational forces
F_g1 = sy.Matrix([0, -m1 * g, 0])
F_g2 = sy.Matrix([0, -m2 * g, 0])
F_g3 = sy.Matrix([0, -m3 * g, 0])

# Torques
tau1 = sy.simplify(Jv_g1.T * F_g1)
tau2 = sy.simplify(Jv_g2.T * F_g2)
tau3 = sy.simplify(Jv_g3.T * F_g3)

# Total torque
tau = tau1 + tau2 + tau3

# Output results
print("Tau 1:")
sy.pprint(tau1)

print("\nTau 2:")
sy.pprint(tau2)

print("\nTau 3:")
sy.pprint(tau3)

print("\nTotal Torque:")
sy.pprint(tau)
