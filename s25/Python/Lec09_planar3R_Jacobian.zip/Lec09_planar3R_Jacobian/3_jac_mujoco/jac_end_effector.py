
import numpy as np
import utility as ram
from forward_kinematics import forward_kinematics

def jac_end_effector(q,parms):

    sol = forward_kinematics(q,parms)

    H01 = sol.H01
    H02 = sol.H02
    H03 = sol.H03
    e0 = sol.e
    R00 = np.eye(3)
    R01 = H01[:3,:3]
    R02 = H02[:3,:3]
    R03 = H03[:3,:3]
    k = np.array([0,0,1])
    o00 = H01[:3,3]
    o01 = H02[:3,3]
    o02 = H03[:3,3] 
    
    #Jv_E = R00*k x (e0 - o00), R01*k x (e0 - o01), R02*k x (e0 - o02)
    Jv_E = np.column_stack( \
            [ram.vec2skew(R00@k)@(e0 - o00), \
            ram.vec2skew(R01@k)@(e0 - o01), \
            ram.vec2skew(R02@k)@(e0 - o02)
            ])


    #Jw_E = R00*k, R01*k, R02*k
    Jw_E = np.column_stack([ R00@k,R01@k, R02@k])

    J_E = np.vstack([Jv_E,Jw_E])
    return J_E