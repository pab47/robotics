
import numpy as np
import utility as ram
from forward_kinematics import forward_kinematics

def jac_com(q,parms):

    sol = forward_kinematics(q,parms)

    l1,l2,l3 = parms;

    H01 = sol.H01
    H02 = sol.H02
    H03 = sol.H03
    e0 = sol.e
    R00 = np.eye(3)
    R01 = H01[:3,:3]
    R02 = H02[:3,:3]
    R03 = H03[:3,:3]
    k = np.array([0,0,1])
    o00 = H01[:3,3]
    o01 = H02[:3,3]
    o02 = H03[:3,3]

    g2 = H02@np.array([0.5*l2,0,0,1])
    g2 = g2[:3]

    g1 = H01@np.array([0.5*l1,0,0,1])
    g1 = g1[:3]

    g3 = H03@np.array([0.5*l3,0,0,1])
    g3 = g3[:3]


    #Jv_G2 = R00*k x (g2 - o00), R01*k x (g2 - o01), zeros(3,1)
    Jv_G2 = np.column_stack( 
            [ram.vec2skew(R00@k)@(g2 - o00), \
            ram.vec2skew(R01@k)@(g2 - o01), \
            np.zeros((3,1))
            ])


    #Jw_G2 = R00*k, R01*k, R02*k
    Jw_G2 = np.column_stack([ R00@k,R01@k, np.zeros((3,1))])

    J_G2 = np.vstack([Jv_G2,Jw_G2])


    Jv_g3 = np.column_stack([
            ram.vec2skew(R00@k)@(g3-o00), \
            ram.vec2skew(R01@k)@(g3-o01), \
            ram.vec2skew(R02@k)@(g3-o02), \
        ]
        )

    Jw_g3 = np.column_stack([
            R00@k,
            R01@k,
            R02@k
        ])

    J_g3 = np.vstack([Jv_g3,Jw_g3])


    Jv_g1 = np.column_stack([
            ram.vec2skew(R00@k)@(g1-o00), \
            np.zeros((3,1)), \
            np.zeros((3,1))
        ]
        )

    Jw_g1 = np.column_stack([
            R00@k,
            np.zeros((3,1)),
            np.zeros((3,1))
        ])

    J_g1 = np.vstack([Jv_g1,Jw_g1])

    return J_G2,J_g1,J_g3
