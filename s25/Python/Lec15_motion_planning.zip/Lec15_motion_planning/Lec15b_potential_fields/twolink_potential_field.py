import numpy as np
import matplotlib.pyplot as plt

def twolink_path_planning():
    parms = {
        'l1': 1,
        'l2': 1,
        'xi1': 0.1,
        'xi2': 0.1,
        'eta2': 1,
        'b': np.array([1.8, 0.75]),
        'rho2_0': 0.4,
        'qf': np.array([np.pi/2, np.pi/2]),
        'time_delay': 0.001
    }

    #potential fields parameters
    count_max = 500
    eps = 5e-2
    alpha = 0.1

    qi = np.array([0, 0])
    parms['qi'] = qi
    qf = parms['qf']

    q = qi
    q_all = q.reshape(1, -1)
    count = 1
    while True:
        torque = get_torque(q, parms)
        torque_mag = np.linalg.norm(torque)
        q = q + alpha * (torque / torque_mag)
        q_all = np.vstack((q_all, q))
        if count == count_max:
            print('Maximum count reached')
            break
        terminate_condition = np.sqrt(np.sum(np.square(qf - q)))
        if terminate_condition < eps:
            print(f'Converged in {count} iterations')
            break
        count += 1

    plt.figure(1)
    plt.subplot(2, 1, 1)
    plt.plot(q_all[:, 0], 'r')
    plt.subplot(2, 1, 2)
    plt.plot(q_all[:, 1], 'r')


    plt.figure(2)
    twolink_animation(q_all, parms)
    plt.close()

def forward_kinematics(l1,l2,theta1,theta2):
    c1 = np.cos(theta1);
    c2 = np.cos(theta2);
    s1 = np.sin(theta1);
    s2 = np.sin(theta2);
    O01 = [0, 0];
    O12 = [l1, 0];

    H01 = np.array([[c1, -s1, O01[0]],
                    [s1, c1,  O01[1]],
                    [0,   0,  1]])
    H12 = np.array([[c2, -s2, O12[0]],
                    [s2, c2,  O12[1]],
                    [0,   0,  1]])
    H02 = np.matmul(H01,H12)


    # %%%%%%%% origin  in world frame  %%%%%%
    o = [0, 0];

    # %%%%% end of link1 in world frame %%%%
    P1 = np.array([l1, 0, 1]);
    P1 = np.transpose(P1)
    P0 = np.matmul(H01,P1)
    p = [P0[0], P0[1]]
    #
    # %%%% end of link 2 in world frame  %%%%%%%
    Q2 = np.array([l2, 0, 1]);
    Q2 = np.transpose(Q2)
    Q0 = np.matmul(H02,Q2)
    q = [Q0[0], Q0[1]]

    return o,p,q

def get_torque(q, parms):
    bx, by = parms['b']
    xi1, xi2 = parms['xi1'], parms['xi2']
    eta2 = parms['eta2']
    rho2_0 = parms['rho2_0']
    qf = parms['qf']
    l1, l2 = parms['l1'], parms['l2']

    theta1, theta2 = q
    theta1f, theta2f = qf

    c1, s1, c12, s12 = get_angles(theta1, theta2)
    c1f, s1f, c12f, s12f = get_angles(theta1f, theta2f)

    Jvo1 = np.array([[-l1 * s1, 0], [l1 * c1, 0]])
    Jvo2 = np.array([[-l1 * s1 - l2 * s12, -l2 * s12], [l1 * c1 + l2 * c12, l2 * c12]])

    F_att1 = -xi1 * np.array([l1 * (c1 - c1f), l1 * (s1 - s1f)])
    F_att2 = -xi2 * np.array([l1 * (c1 - c1f) + l2 * (c12 - c12f), l1 * (s1 - s1f) + l2 * (s12 - s12f)])

    rho2 = np.array([(l1 * c1 + l2 * c12 - bx),(l1 * s1 + l2 * s12 - by)])
    rho2_mag = np.linalg.norm(rho2)
    rho2_unit_vector = rho2 / rho2_mag

    F_rep2 = np.zeros(2)
    if rho2_mag < rho2_0:
      F_rep2 = eta2 * ((1 / rho2_mag) - (1 / rho2_0)) * (1 / (rho2_mag**2)) * rho2_unit_vector

    torque = np.dot(Jvo1.T, F_att1) + np.dot(Jvo2.T, F_att2) + np.dot(Jvo2.T, F_rep2)
    return torque

def get_angles(theta1, theta2):
  c1, s1 = np.cos(theta1), np.sin(theta1)
  c12, s12 = np.cos(theta1 + theta2), np.sin(theta1 + theta2)

  return c1, s1, c12, s12


def twolink_animation(x, parms):
  b = parms['b']
  rho2_0 = parms['rho2_0']

  qi = parms['qi']
  qf = parms['qf']

  [_,_,endOfLink2qi] = forward_kinematics(parms['l1'],parms['l2'],qi[0],qi[1])
  [_,_,endOfLink2qf] = forward_kinematics(parms['l1'],parms['l2'],qf[0],qf[1])

  theta = np.linspace(0, 2 * np.pi)
  xx2 = b[0] + rho2_0 * np.cos(theta)
  yy2 = b[1] + rho2_0 * np.sin(theta)

  for i in range(len(x)):

    [_,endOfLink1,endOfLink2] = forward_kinematics(parms['l1'],parms['l2'],x[i, 0],x[i, 1])


    plt.plot(b[0],b[1],color = 'black',marker = 'o',markersize=5)
    plt.plot(xx2, yy2, 'k')

    # %Draw line from origin to end of link 1
    tmp1, = plt.plot([0, endOfLink1[0]],[0, endOfLink1[1]],linewidth=5, color='red')

    # %Draw line from end of link 1 to end of link 2
    tmp2, = plt.plot([endOfLink1[0], endOfLink2[0]],[endOfLink1[1], endOfLink2[1]],linewidth=5, color='blue')

    plt.xlabel("x")
    plt.ylabel("y")

    plt.xlim(-3,3)
    plt.ylim(-3,3)
    plt.gca().set_aspect('equal')

    plt.pause(parms['time_delay'])
    #plt.pause(0.001)
    tmp1.remove()
    tmp2.remove()

    # # Plot the start and end points
    plt.scatter(endOfLink2qi[0], endOfLink2qi[1], c='red', marker='o')
    plt.text(endOfLink2qi[0] + 0.1, endOfLink2qi[1] + 0.1, 'start')
    plt.scatter(endOfLink2qf[0], endOfLink2qf[1],  c='red', marker='x')
    plt.text(endOfLink2qf[0] + 0.1, endOfLink2qf[1] + 0.1, 'end')


twolink_path_planning()
