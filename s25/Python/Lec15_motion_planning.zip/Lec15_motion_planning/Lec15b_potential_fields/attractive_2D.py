import numpy as np
import matplotlib.pyplot as plt

# Create meshgrid
X, Y = np.meshgrid(np.arange(-8, 8, 0.05), np.arange(-8, 8, 0.05))

xf = 1
yf = 1
xi = 10

# Quadratic potential
U_att1 = 0.5 * xi * ((X - xf) ** 2 + (Y - yf) ** 2)

# Conic potential
U_att2 = xi * np.sqrt((X - xf) ** 2 + (Y - yf) ** 2)

# Plot quadratic potential
fig1 = plt.figure(1)
ax1 = plt.axes(projection='3d')
ax1.plot_surface(X, Y, U_att1)
ax1.set_title('Quadratic')

# Plot contour of quadratic potential
fig2 = plt.figure(2)
ax2 = plt.axes(projection='3d')
contour_filled = ax2.contourf(X, Y, U_att1, levels=15, cmap='viridis')
ax2.plot(xf, yf, 'r*')
ax2.set_title('Quadratic')
ax2.grid(True)
ax2.view_init(elev=90, azim=0) # Set the view to look from the top (x-y view)
fig2.colorbar(contour_filled, ax=ax2, label='Contour Levels') # Add a colorbar to indicate the contour levels


# Plot conic potential
fig3 = plt.figure(3)
ax3 = plt.axes(projection='3d')
ax3.plot_surface(X, Y, U_att2)
ax3.set_title('Conic')

# Plot contour of conic potential
fig4 = plt.figure(4)
ax4 = plt.axes(projection='3d')
contour_filled = ax4.contourf(X, Y, U_att2, levels=15, cmap='viridis')
ax4.plot(xf, yf, 'r*')
ax4.set_title('Conic')
ax4.grid(True)
ax4.view_init(elev=90, azim=0) # Set the view to look from the top (x-y view)
fig4.colorbar(contour_filled, ax=ax4, label='Contour Levels') # Add a colorbar to indicate the contour levels


# Display all figures
plt.show()
