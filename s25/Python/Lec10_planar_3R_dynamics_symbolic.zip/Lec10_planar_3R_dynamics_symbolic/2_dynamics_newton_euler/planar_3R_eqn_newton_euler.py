import sympy as sy

#define symbolic quantities
theta1,theta2,theta3  = sy.symbols('theta1 theta2 theta3', real=True)
omega1,omega2,omega3  = sy.symbols('omega1 omega2 omega3', real=True)
alpha1,alpha2,alpha3  = sy.symbols('alpha1 alpha2 alpha3', real=True)
m1,m2,m3,Iz1,Iz2,Iz3,g  = sy.symbols('m1 m2 m3 Iz1 Iz2 Iz3 g', real=True)
l1,l2,l3        = sy.symbols('l1 l2 l3', real=True)

# %%%%%%% unit vectors %%%%%%%
i = sy.Matrix([1, 0, 0]);
j = sy.Matrix([0, 1, 0]);
k = sy.Matrix([0, 0, 1]);

#1a) position vectors
c1 = sy.cos(theta1); s1 = sy.sin(theta1)
c2 = sy.cos(theta2); s2 = sy.sin(theta2)
c3 = sy.cos(theta3); s3 = sy.sin(theta3)


R01 = sy.Matrix([[ c1, -s1, 0],
                  [s1,   c1,  0],
                  [0, 0, 1]])
O01 = sy.Matrix([ [0],[0],[0]])
H01 = sy.Matrix.vstack(sy.Matrix.hstack(R01, O01), sy.Matrix([[0, 0, 0, 1]]))

R12 = sy.Matrix([ [ c2, -s2, 0],
                  [s2, c2,  0],
                  [0,     0,     1] ])
O12 = sy.Matrix([ [l1], [0],[0]])
H12 = sy.Matrix.vstack(sy.Matrix.hstack(R12, O12), sy.Matrix([[0, 0, 0, 1]]))
H02 = sy.simplify(H01*H12)

R23 = sy.Matrix([ [ c3, -s3, 0],
                  [s3, c3,  0],
                  [0,     0,     1] ])
O23 = sy.Matrix([ [l2], [0],[0]])
H23 = sy.Matrix.vstack(sy.Matrix.hstack(R23, O23), sy.Matrix([[0, 0, 0, 1]]))
H03 = sy.simplify(H02*H23)


R34 = sy.Matrix([[ 1, 0, 0],
                 [ 0, 1,  0],
                  [0, 0, 1]
                      ])
O34 = sy.Matrix([l3,0,0])
H34 = sy.Matrix.vstack(sy.Matrix.hstack(R34, O34), sy.Matrix([[0, 0, 0, 1]]))
H04 = sy.simplify(H03*H34)

R02 = H02[:3, :3]
R03 = H03[:3, :3]
R04 = H04[:3, :3]

R10 = R01.T
R21 = R12.T
R32 = R23.T

qdot = sy.Matrix([omega1, omega2, omega3])
qddot = sy.Matrix([alpha1, alpha2, alpha3])


#Velocity
w00 = sy.Matrix([0, 0, 0]); v00 = sy.Matrix([0, 0, 0])
w11 = R10*w00 + qdot[0]*k; v11 = R10*(v00 + w00.cross(O01));
w22 = R21*w11 + qdot[1]*k; v22 = R21*(v11 + w11.cross(O12));
w33 = R32*w22 + qdot[2]*k; v33 = R32*(v22 + w22.cross(O23));

#Energy
C1_1 = sy.Matrix([0.5*l1,0,0])
C2_2 = sy.Matrix([0.5*l2,0,0])
C3_3 = sy.Matrix([0.5*l3,0,0])


C1_0 = H01*C1_1.col_join(sy.Matrix([1])); C1_0 =  C1_0[:-1,:]
C2_0 = H02*C2_2.col_join(sy.Matrix([1])); C2_0 =  C2_0[:-1,:]
C3_0 = H03*C3_3.col_join(sy.Matrix([1])); C3_0 =  C3_0[:-1,:]

vC1_0 = v11 + w11.cross(C1_1);
vC2_0 = v22 + w22.cross(C2_2);
vC3_0 = v33 + w33.cross(C3_3);

w01 = R01*w11;
w02 = R02*w22;
w03 = R03*w33;

Iner1 = sy.diag(0, 0, Iz1);
Iner2 = sy.diag(0, 0, Iz2);
Iner3 = sy.diag(0, 0, Iz3);
KE = 0.5*m1*vC1_0.dot(vC1_0)+ \
     0.5*m2*vC2_0.dot(vC2_0)+ \
     0.5*m3*vC3_0.dot(vC3_0)+ \
     0.5*w01.dot(Iner1*w01) + \
     0.5*w02.dot(Iner2*w02) + \
     0.5*w03.dot(Iner3*w03);
PE = m1*g*C1_0[1]+m2*g*C2_0[1]+m3*g*C3_0[1];
print('KE = ', sy.simplify(KE))
print('PE = ', sy.simplify(PE))
print('TE = KE + PE')
print(' ')

#acceleration stuff
wdot00 = sy.Matrix([0, 0, 0]); vdot00 = sy.Matrix([0, 0, 0])

wdot11 = R10*wdot00 + (R10*w00).cross(qdot[0]*k) + qddot[0]*k;
vdot11 = R10*(vdot00 + wdot00.cross(O01) + w00.cross(w00.cross(O01)));

wdot22 = R21*wdot11 + (R21*w11).cross(qdot[1]*k) + qddot[1]*k;
vdot22 = R21*(vdot11 + wdot11.cross(O12) + w11.cross(w11.cross(O12)));

wdot33 = R32*wdot22 + (R32*w22).cross(qdot[2]*k) + qddot[2]*k;
vdot33 = R32*(vdot22 + wdot22.cross(O23) + w22.cross(w22.cross(O23)));

vdotC11 = vdot11 + wdot11.cross(C1_1) + w11.cross(w11.cross(C1_1));
vdotC22 = vdot22 + wdot22.cross(C2_2) + w22.cross(w22.cross(C2_2));
vdotC33 = vdot33 + wdot33.cross(C3_3) + w33.cross(w33.cross(C3_3));


#forces and moments
grav = sy.Matrix([0, -g, 0])

#BACKWARD RECURSION
F1 = m1*vdotC11;
F2 = m2*vdotC22;
F3 = m3*vdotC33;

N1 = Iner1*wdot11 + w11.cross(Iner1*w11);
N2 = Iner2*wdot22 + w22.cross(Iner2*w22);
N3 = Iner3*wdot33 + w33.cross(Iner3*w33);

f4 = sy.Matrix([0, 0, 0]); n4 = sy.Matrix([0, 0, 0])

f3 = R34*f4 + F3 - R32*R21*R10*m3*grav;
n3 = N3+R34*n4+C3_3.cross(f3)+(O34-C3_3).cross(R34*f4);
#n3 is the same as tau3

f2 = R23*f3 + F2 - R21*R10*m2*grav;
n2 = N2+R23*n3+C2_2.cross(f2)+(O23-C2_2).cross(R23*f3);

f1 = R12*f2 + F1 - R10*m1*grav;
n1 = N1+R12*n2+C1_1.cross(f1)+(O12-C1_1).cross(R12*f2);

# torques
tau = sy.Matrix([n1[2],n2[2],n3[2]])
#n1[2] because first joint rotates about k (=2) axis

#derive equations

#M(theta)*thetaddot + C(theta,thetadot) + G(theta,g) = 0
M = tau.jacobian(qddot)
#N1 = C1+G1
#M thetaddot + N = 0
N1 = tau[0].subs([ (alpha1,0), (alpha2,0), (alpha3,0)])
N2 = tau[1].subs([ (alpha1,0), (alpha2,0), (alpha3,0)])
N3 = tau[2].subs([ (alpha1,0), (alpha2,0), (alpha3,0)])
G1 = N1.subs([ (omega1,0), (omega2,0), (omega3,0)])
G2 = N2.subs([ (omega1,0), (omega2,0), (omega3,0)])
G3 = N3.subs([ (omega1,0), (omega2,0), (omega3,0)])
C1 = N1 - G1
C2 = N2 - G2
C3 = N3 - G3

print('M11 = ', sy.simplify(M[0,0]))
print('M12 = ', sy.simplify(M[0,1]))
print('M13 = ', sy.simplify(M[0,2]))
print('M21 = ', sy.simplify(M[1,0]))
print('M22 = ', sy.simplify(M[1,1]))
print('M23 = ', sy.simplify(M[1,2]))
print('M31 = ', sy.simplify(M[2,0]))
print('M32 = ', sy.simplify(M[2,1]))
print('M33 = ', sy.simplify(M[2,2]),'\n')

print('C1 = ', sy.simplify(C1))
print('C2 = ', sy.simplify(C2))
print('C3 = ', sy.simplify(C3),'\n')

print('G1 = ', sy.simplify(G1))
print('G2 = ', sy.simplify(G2))
print('G3 = ', sy.simplify(G3),'\n')
