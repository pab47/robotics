import sympy as sy

#define symbolic quantities
theta1,theta2,theta3  = sy.symbols('theta1 theta2 theta3', real=True)
omega1,omega2,omega3  = sy.symbols('omega1 omega2 omega3', real=True)
alpha1,alpha2,alpha3  = sy.symbols('alpha1 alpha2 alpha3', real=True)
m1,m2,m3,Iz1,Iz2,Iz3,g  = sy.symbols('m1 m2 m3 Iz1 Iz2 Iz3 g', real=True)
l1,l2,l3        = sy.symbols('l1 l2 l3', real=True)

#1a) position vectors
c1 = sy.cos(theta1); s1 = sy.sin(theta1)
c2 = sy.cos(theta2); s2 = sy.sin(theta2)
c3 = sy.cos(theta3); s3 = sy.sin(theta3)

R01 = sy.Matrix([ [ c1, -s1, 0],
                  [s1, c1,  0],
                  [0,     0,     1] ])
O01 = sy.Matrix([ [0], [0],[0]])
H01 = sy.Matrix.vstack(sy.Matrix.hstack(R01, O01), sy.Matrix([[0, 0, 0, 1]]))

R12 = sy.Matrix([ [ c2, -s2, 0],
                  [s2, c2,  0],
                  [0,     0,     1] ])
O12 = sy.Matrix([ [l1], [0],[0]])
H12 = sy.Matrix.vstack(sy.Matrix.hstack(R12, O12), sy.Matrix([[0, 0, 0, 1]]))
H02 = sy.simplify(H01*H12)

R23 = sy.Matrix([ [ c3, -s3, 0],
                  [s3, c3,  0],
                  [0,     0,     1] ])
O23 = sy.Matrix([ [l2], [0],[0]])
H23 = sy.Matrix.vstack(sy.Matrix.hstack(R23, O23), sy.Matrix([[0, 0, 0, 1]]))
H03 = sy.simplify(H02*H23)

G1 = H01*sy.Matrix([0.5*l1, 0, 0, 1])
G2 = H02*sy.Matrix([0.5*l2, 0, 0, 1])
G3 = H03*sy.Matrix([0.5*l3, 0, 0, 1])

x_G1 = sy.Matrix([G1[0]])
y_G1 = sy.Matrix([G1[1]])
x_G2 = sy.Matrix([G2[0]])
y_G2 = sy.Matrix([G2[1]])
x_G3 = sy.Matrix([G3[0]])
y_G3 = sy.Matrix([G3[1]])

#1b) velocity vectors
q = sy.Matrix([theta1, theta2, theta3])
qdot = sy.Matrix([omega1, omega2, omega3])
qddot = sy.Matrix([alpha1, alpha2, alpha3])
v_G1_x = x_G1.jacobian(q)*qdot #d(x_G1)/dq = jacobian  d = partial derivate
v_G1_y = y_G1.jacobian(q)*qdot
v_G2_x = x_G2.jacobian(q)*qdot
v_G2_y = y_G2.jacobian(q)*qdot
v_G3_x = x_G3.jacobian(q)*qdot
v_G3_y = y_G3.jacobian(q)*qdot
v_G1 = sy.Matrix([v_G1_x,v_G1_y])
v_G2 = sy.Matrix([v_G2_x,v_G2_y])
v_G3 = sy.Matrix([v_G3_x,v_G3_y])

#2) Lagrangian
T = 0.5*m1*v_G1.dot(v_G1) + \
    0.5*m2*v_G2.dot(v_G2) + \
    0.5*m3*v_G3.dot(v_G3) + \
    0.5*Iz1*omega1*omega1 + \
    0.5*Iz2*(omega1+omega2)*(omega1+omega2) + \
    0.5*Iz3*(omega1+omega2+omega3)*(omega1+omega2+omega3)
V = m1*g*G1[1] + m2*g*G2[1] + + m3*g*G3[1]
L = T-V

print('KE = ', sy.simplify(T))
print('PE = ', sy.simplify(V))
print('TE = KE+PE \n')

# print(L)
# print(type(T))
# print(type(V))
# print(type(L))

#3) Derive equations
dLdqdot = []
ddt_dLdqdot = []
dLdq = []
EOM = []
mm = len(qddot)
for i in range(0,mm):
    dLdqdot.append(sy.diff(L,qdot[i]))
    tmp = 0;
    for j in range(0,mm):
        tmp += sy.diff(dLdqdot[i],q[j])*qdot[j]+ sy.diff(dLdqdot[i],qdot[j])*qddot[j]
    ddt_dLdqdot.append(tmp)
    dLdq.append(sy.diff(L,q[i]));
    EOM.append(ddt_dLdqdot[i] - dLdq[i])

EOM = sy.Matrix([EOM[0],EOM[1],EOM[2]])
# print(len(EOM))
# print(type(qddot))
# print(type(EOM))
# print('EOM0')
# print(sy.simplify(EOM[0]))
# print('EOM1')
# print(sy.simplify(EOM[1]))
# print('EOM2')
# print(sy.simplify(EOM[2]))

M = EOM.jacobian(qddot)
#N = C + G
N1 = EOM[0].subs([ (alpha1,0), (alpha2,0), (alpha3,0)])
N2 = EOM[1].subs([ (alpha1,0), (alpha2,0), (alpha3,0)])
N3 = EOM[2].subs([ (alpha1,0), (alpha2,0), (alpha3,0)])
G1 = N1.subs([ (omega1,0), (omega2,0), (omega3,0)])
G2 = N2.subs([ (omega1,0), (omega2,0), (omega3,0)])
G3 = N3.subs([ (omega1,0), (omega2,0), (omega3,0)])
C1 = N1 - G1
C2 = N2 - G2
C3 = N3 - G3

# print(EOM.shape)
# print(M.shape)
print('M11 = ', sy.simplify(M[0,0]))
print('M12 = ', sy.simplify(M[0,1]))
print('M13 = ', sy.simplify(M[0,2]))
print('M21 = ', sy.simplify(M[1,0]))
print('M22 = ', sy.simplify(M[1,1]))
print('M23 = ', sy.simplify(M[1,2]))
print('M31 = ', sy.simplify(M[2,0]))
print('M32 = ', sy.simplify(M[2,1]))
print('M33 = ', sy.simplify(M[2,2]),'\n')

print('C1 = ', sy.simplify(C1))
print('C2 = ', sy.simplify(C2))
print('C3 = ', sy.simplify(C3),'\n')

print('G1 = ', sy.simplify(G1))
print('G2 = ', sy.simplify(G2))
print('G3 = ', sy.simplify(G3),'\n')
