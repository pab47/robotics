#Unconstrained optimization using BFGS
#https://docs.scipy.org/doc/scipy/tutorial/optimize.html#broyden-fletcher-goldfarb-shanno-algorithm-method-bfgs
import scipy.optimize as opt

def fun(paramt):
    x1,x2 = paramt
    return 100*(x2-x1**2)**2 + (1-x1)**2


x0 = [5,10]
#res = optimize.minimize(fun,x0)
res = opt.minimize(fun,x0,method='BFGS')

print(res.x)
