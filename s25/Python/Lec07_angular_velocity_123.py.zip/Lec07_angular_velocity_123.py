import sympy as sy

# Define symbolic variables
phi, theta, psi = sy.symbols('phi theta psi', real=True)  # Euler angles
phidot, thetadot, psidot = sy.symbols('phidot thetadot psidot', real=True)

# Define unit vectors
i = sy.Matrix([1, 0, 0])
j = sy.Matrix([0, 1, 0])
k = sy.Matrix([0, 0, 1])

# Define rotation matrices
R_x = sy.Matrix([
    [1, 0, 0],
    [0, sy.cos(phi), -sy.sin(phi)],
    [0, sy.sin(phi), sy.cos(phi)]
])

R_y = sy.Matrix([
    [sy.cos(theta), 0, sy.sin(theta)],
    [0, 1, 0],
    [-sy.sin(theta), 0, sy.cos(theta)]
])

R_z = sy.Matrix([
    [sy.cos(psi), -sy.sin(psi), 0],
    [sy.sin(psi), sy.cos(psi), 0],
    [0, 0, 1]
])

# Angular velocity in the world frame
# om = (psidot * k) + R_z * (thetadot * j) + R_z * R_y * (phidot * i)  # 3-2-1
omega = (phidot * i) + R_x * (thetadot * j) + R_x * R_y * (psidot * k)  # 1-2-3

#R_we = sy.jacobian(om, [phidot, thetadot, psidot])
A = omega.jacobian([phidot, thetadot, psidot])

# Simplify and compute determinant and inverse of R_we
det_A = sy.simplify(sy.det(A))
inv_A = sy.simplify(A.inv())

print("Determinant of A:", det_A)
print("A = ")
sy.pprint(A)
print("Inverse of A:")
sy.pprint(inv_A)

# Angular velocity in the body frame
# om_b = (phidot * i) + R_x.T * (thetadot * j) + R_x.T * R_y.T * (psidot * k)  # 3-2-1
Omega = (psidot * k) + R_z.T * (thetadot * j) + R_z.T * R_y.T * (phidot * i)  # 1-2-3

B = Omega.jacobian([phidot, thetadot, psidot])

# Simplify and compute determinant and inverse of R_be
det_B = sy.simplify(sy.det(B))
inv_B = sy.simplify(B.inv())

print("Determinant of B:", det_B)
print("B =");
sy.pprint(B)
print("Inverse of B:")
sy.pprint(inv_B)
