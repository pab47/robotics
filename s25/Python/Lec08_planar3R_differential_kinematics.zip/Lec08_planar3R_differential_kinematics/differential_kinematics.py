import numpy as np
from forward_kinematics import forward_kinematics
import utility as ram
from types import SimpleNamespace

def differential_kinematics(q,u,parms):

    l1,l2,l3 = parms;

    sol = forward_kinematics(q,parms)
    H01 = sol.H01
    H12 = sol.H12
    H23 = sol.H23

    w00 = np.array([0,0,0])
    v00 = np.array([0,0,0])

    k = np.array([0,0,1])

    R01 = H01[:3,:3]
    o01 = H01[:3,3]
    w11 = R01.T@w00 + u[0]*k
    v11 = R01.T@(v00 + ram.vec2skew(w00)@o01)

    R12 = H12[:3,:3]
    o12 = H12[:3,3]
    w22 = R12.T@w11 + u[1]*k
    v22 = R12.T@(v11 + ram.vec2skew(w11)@o12)

    R23 = H23[:3,:3]
    o23 = H23[:3,3]
    w33 = R23.T@w22 + u[2]*k
    v33 = R23.T@(v22 + ram.vec2skew(w22)@o23)

    R02 = R01@R12
    R03 = R02@R23

    w1 = R01@w11
    w2 = R02@w22
    w3 = R03@w33

    v1 = R01@v11
    v2 = R02@v22
    v3 = R03@v33

    pc1 = np.array([0.5*l1,0,0])
    pc2 = np.array([0.5*l2,0,0])
    pc3 = np.array([0.5*l3,0,0])

    vC1_1 = v11 + ram.vec2skew(w11)@pc1
    vC2_2 = v22 + ram.vec2skew(w22)@pc2
    vC3_3 = v33 + ram.vec2skew(w33)@pc3

    vC1 = R01@vC1_1
    vC2 = R02@vC2_2
    vC3 = R03@vC3_3

    e3 = np.array([l3,0,0])
    ve_3 = v33 + ram.vec2skew(w33)@e3
    we_3 = w33

    ve = R03@ve_3
    we = R03@we_3

    sol2 = SimpleNamespace(
        ve=ve, we=we,
        vC1=vC1,vC2=vC2,vC3=vC3,
        v1=v1,v2=v2,v3=v3,
        w1=w1,w2=w2,w3=w3
        )

    return sol2
    #print(w11)
    #print(v11)