import mujoco as mj
from mujoco.glfw import glfw
import numpy as np
import os
from forward_kinematics import forward_kinematics
from scipy.optimize import fsolve
import matplotlib.pyplot as plt
from quintic_interp import quintic_interp
from RNEA import RNEA
from TMT import TMT
import time


flag_traj_generation_mode = 0

t0 = 1 #start time
tf = t0+3  #end time


#xml_path = '../universal_robots_ur5e/scene.xml' #xml file (assumes this is in the same folder as this file)
xml_path = '../universal_robots_ur5e/scene_act_trq.xml' #xml file (assumes this is in the same folder as this file)
simend = tf+1
print_camera_config = 0 #set to 1 to print camera config
                        #this is useful for initializing view of the model)

# For callback functions
button_left = False
button_middle = False
button_right = False
lastx = 0
lasty = 0


C_py = np.zeros(6)
G_py = np.zeros(6)
CG_py = np.zeros(6)
M_py_TMT = np.identity(6)

count = 0


def init_controller(model,data):
    #initialize the controller here. This function is called once, in the beginning
    pass

def controller(model, data):
    #put the controller here. This function is called inside the simulation.

    global C_py, G_py, CG_py
    global M_py_TMT
    global count

    count +=1
    #tic = time.time()  # Start timer

    if (count%20==0):
        C_py,G_py,CG_py,_ = RNEA(q,u,0)

        M_py_TMT = TMT(q)


    #toc = time.time()  # End timer
    #print(f"Elapsed time: {toc - tic:.4f} seconds")

    M_mj = np.zeros((model.nv,model.nv ))
    mj.mj_fullM(model, M_mj, data.qM)
    CG_mj = data.qfrc_bias.copy()

    tau_ff = M_py_TMT@ud + CG_py
    tau_fb = -kp*(data.qpos-q)-kv*(data.qvel-u)
    tau_comp_trq = M_py_TMT@(ud+tau_fb) + CG_mj

    # # 1) PD control
    #ctrl = tau_fb.copy()

    # # 2) Gravity + PD Control (2 ways)
    #ctrl = G_py.copy() + tau_fb.copy() #use reference G comp
    #ctrl = G_mj.copy() + tau_fb.copy() #use actual G comp

    ## 3) Feedforwrd + Feedback
    ctrl = tau_ff.copy() + tau_fb.copy()

    ## 4) Computed Torque control
    #ctrl = tau_comp_trq.copy()

    data.ctrl = ctrl.copy(); #np.concatenate((q.copy(),u.copy()))
    #pass

def keyboard(window, key, scancode, act, mods):
    if act == glfw.PRESS and key == glfw.KEY_BACKSPACE:
        mj.mj_resetData(model, data)
        mj.mj_forward(model, data)

def mouse_button(window, button, act, mods):
    # update button state
    global button_left
    global button_middle
    global button_right

    button_left = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_LEFT) == glfw.PRESS)
    button_middle = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_MIDDLE) == glfw.PRESS)
    button_right = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_RIGHT) == glfw.PRESS)

    # update mouse position
    glfw.get_cursor_pos(window)

def mouse_move(window, xpos, ypos):
    # compute mouse displacement, save
    global lastx
    global lasty
    global button_left
    global button_middle
    global button_right

    dx = xpos - lastx
    dy = ypos - lasty
    lastx = xpos
    lasty = ypos

    # no buttons down: nothing to do
    if (not button_left) and (not button_middle) and (not button_right):
        return

    # get current window size
    width, height = glfw.get_window_size(window)

    # get shift key state
    PRESS_LEFT_SHIFT = glfw.get_key(
        window, glfw.KEY_LEFT_SHIFT) == glfw.PRESS
    PRESS_RIGHT_SHIFT = glfw.get_key(
        window, glfw.KEY_RIGHT_SHIFT) == glfw.PRESS
    mod_shift = (PRESS_LEFT_SHIFT or PRESS_RIGHT_SHIFT)

    # determine action based on mouse button
    if button_right:
        if mod_shift:
            action = mj.mjtMouse.mjMOUSE_MOVE_H
        else:
            action = mj.mjtMouse.mjMOUSE_MOVE_V
    elif button_left:
        if mod_shift:
            action = mj.mjtMouse.mjMOUSE_ROTATE_H
        else:
            action = mj.mjtMouse.mjMOUSE_ROTATE_V
    else:
        action = mj.mjtMouse.mjMOUSE_ZOOM

    mj.mjv_moveCamera(model, action, dx/height,
                      dy/height, scene, cam)

def scroll(window, xoffset, yoffset):
    action = mj.mjtMouse.mjMOUSE_ZOOM
    mj.mjv_moveCamera(model, action, 0.0, -0.05 *
                      yoffset, scene, cam)

#get the full path
dirname = os.path.dirname(__file__)
abspath = os.path.join(dirname + "/" + xml_path)
xml_path = abspath

# MuJoCo data structures
model = mj.MjModel.from_xml_path(xml_path)  # MuJoCo model
data = mj.MjData(model)                # MuJoCo data
cam = mj.MjvCamera()                        # Abstract camera
opt = mj.MjvOption()                        # visualization options

model.opt.timestep = 0.001

# Init GLFW, create window, make OpenGL context current, request v-sync
glfw.init()
window = glfw.create_window(1200, 900, "Demo", None, None)
glfw.make_context_current(window)
glfw.swap_interval(1)

# initialize visualization data structures
mj.mjv_defaultCamera(cam)
mj.mjv_defaultOption(opt)
scene = mj.MjvScene(model, maxgeom=10000)
context = mj.MjrContext(model, mj.mjtFontScale.mjFONTSCALE_150.value)

# install GLFW mouse and keyboard callbacks
glfw.set_key_callback(window, keyboard)
glfw.set_cursor_pos_callback(window, mouse_move)
glfw.set_mouse_button_callback(window, mouse_button)
glfw.set_scroll_callback(window, scroll)

# Example on how to set camera configuration
# cam.azimuth = 90
# cam.elevation = -45
# cam.distance = 2
# cam.lookat = np.array([0.0, 0.0, 0])
cam.azimuth = -143.92066650390623 ; cam.elevation = -30.10462036132817 ; cam.distance =  2.1879597135804874
cam.lookat =np.array([ 0.0 , 0.0 , 0.0 ])


# 1) End-effector site
site_id = model.site("attachment_site").id

# 2) Name of bodies we wish to apply gravity compensation to.
#we have not included the body called "base"
body_names = [
    "shoulder_link",
    "upper_arm_link",
    "forearm_link",
    "wrist_1_link",
    "wrist_2_link",
    "wrist_3_link",
]
body_ids = [model.body(name).id for name in body_names]
#print(body_ids)
#model.body_gravcomp[body_ids] = 1.0

# 3) Joint / actuators have the same names
joint_names = [
    "shoulder_pan",
    "shoulder_lift",
    "elbow",
    "wrist_1",
    "wrist_2",
    "wrist_3",
]

#4) Joint ids
joint_ids = np.array([model.joint(name).id for name in joint_names])

# 5) Note that actuator names are the same as joint names in this case.
#actuator_ids = np.array([model.actuator(name).id for name in joint_names])

# 6) Initial joint configuration saved as a keyframe in the XML file.
key_id = model.key("home").id
key_qpos = model.key_qpos[key_id]  #Access qpos
#key_ctrl = model.key_ctrl[key_id] #Access ctrl


#global variables
q = np.zeros(6)
u = np.zeros(6)
ud = np.zeros(6)
kp = np.array([5000,5000,5000,100,100,100])
kv = np.array([20,20,20,0.2,0.2,0.2])


#initialize and final pose
q0 = np.array([-1.5708, -1.5708,  1.5708, -1.5708, -1.5708,  0. ])
qf = np.array([np.pi, -np.pi,  0, 0, 0, np.pi ])
u0 = np.zeros(6)

#to store the data
time_all = []
q_all = np.empty((0, 6))
u_all = np.empty((0, 6))
qpos_all = np.empty((0, 6))
qvel_all = np.empty((0, 6))

opt.frame = mj.mjtFrame.mjFRAME_SITE #or use 3 (check https://mujoco.readthedocs.io/en/latest/APIreference/APItypes.html#mjvoption)

#print(model.opt.timestep)
#model.opt.timestep = 0.001

#print(model.opt.gravity)

#initialize the controller
init_controller(model,data)


#set the controller (implicit control)
#mj.set_mjcb_control(controller)


if (0):
    for actuator_no in range(0,6):
        print('actuator (pos): ',actuator_no)
        print(model.actuator_dynprm[actuator_no,:3])
        print(model.actuator_gainprm[actuator_no,:3])
        print(model.actuator_biasprm[actuator_no,:3])

        # print('actuator (vel): ',actuator_no+6)
        # print(model.actuator_dynprm[actuator_no+6,:3])
        # print(model.actuator_gainprm[actuator_no+6,:3])
        # print(model.actuator_biasprm[actuator_no+6,:3])
        # print('********')


while not glfw.window_should_close(window):
    time_prev = data.time

    if (data.time<0.01):
        # Reset the simulation to the initial keyframe.
        mj.mj_resetDataKeyframe(model, data, key_id)
        data.qpos = q0.copy()
        data.qvel = u0.copy()


    while (data.time - time_prev < 1.0/60.0):

        q,u,ud = quintic_interp(data.time,t0,tf,q0,qf)

        if (flag_traj_generation_mode==1):
            mj.mj_forward(model,data)
            data.time += model.opt.timestep
            data.qpos = q.copy()
            data.qvel = u.copy()
        else:
            controller(model,data)
            mj.mj_step(model,data)

        qpos = data.qpos.copy()
        qvel = data.qvel.copy()


        if (data.time>=t0 and data.time<=tf):
            time_all.append(data.time-t0)
            q_all = np.vstack([q_all, q.copy()])
            u_all = np.vstack([u_all, u.copy()])
            qpos_all = np.vstack([qpos_all, qpos.copy()])
            qvel_all = np.vstack([qvel_all, qvel.copy()])

    if (data.time>=simend):
        break;

    # get framebuffer viewport
    viewport_width, viewport_height = glfw.get_framebuffer_size(
        window)
    viewport = mj.MjrRect(0, 0, viewport_width, viewport_height)

    #print camera configuration (help to initialize the view)
    if (print_camera_config==1):
        print('cam.azimuth =',cam.azimuth,';','cam.elevation =',cam.elevation,';','cam.distance = ',cam.distance)
        print('cam.lookat =np.array([',cam.lookat[0],',',cam.lookat[1],',',cam.lookat[2],'])')

    # Update scene and render
    mj.mjv_updateScene(model, data, opt, None, cam,
                       mj.mjtCatBit.mjCAT_ALL.value, scene)
    mj.mjr_render(viewport, scene, context)

    # swap OpenGL buffers (blocking call due to v-sync)
    glfw.swap_buffers(window)

    # process pending GUI events, call GLFW callbacks
    glfw.poll_events()

glfw.terminate()


colors_ref = ['black', 'black', 'black', 'black', 'black', 'black']
linestyles_ref = ['--', '--', '--', '--', '--', '--']

colors = ['cyan', 'red', 'blue', 'green', 'purple', 'orange']
linestyles = ['-', '-', '-', '-', '-', '-']

# Create subplots (3 rows, 2 column)
fig1, axes1 = plt.subplots(3, 2, figsize=(10, 8), sharex=True)  # Share x-axis for alignment

for i in range(6):
    row, col = divmod(i, 2)  # Convert index to row, column in 3x2 grid
    axes1[row, col].plot(time_all, q_all[:, i], color=colors_ref[i], linestyle=linestyles_ref[i], linewidth=2,label='ref')
    axes1[row, col].plot(time_all, qpos_all[:, i], color=colors[i], linestyle=linestyles[i], linewidth=4,label='act',alpha=0.3)
    axes1[row, col].set_ylabel(f'q_{i}')  # Label for each subplot
    axes1[row, col].grid(True)
    axes1[row, col].legend()  # Add legend inside each subplot

# Common x-label for bottom row
for ax in axes1[-1, :]:
    ax.set_xlabel('Time')

# Create subplots (3 rows, 2 column)
fig2, axes2 = plt.subplots(3, 2, figsize=(10, 8), sharex=True)  # Share x-axis for alignment

for i in range(6):
    row, col = divmod(i, 2)  # Convert index to row, column in 3x2 grid
    axes2[row, col].plot(time_all, u_all[:, i], color=colors_ref[i], linestyle=linestyles_ref[i], linewidth=2,label='ref')
    axes2[row, col].plot(time_all, qvel_all[:, i], color=colors[i], linestyle=linestyles[i], linewidth=4,label='act',alpha=0.3)
    axes2[row, col].set_ylabel(f'u_{i}')  # Label for each subplot
    axes2[row, col].grid(True)
    axes2[row, col].legend()  # Add legend inside each subplot

# Common x-label for bottom row
for ax in axes2[-1, :]:
    ax.set_xlabel('Time')


plt.show(block=False)  # Non-blocking display
plt.pause(10)  # Pause for 2 seconds
plt.close()  # Close the plot
