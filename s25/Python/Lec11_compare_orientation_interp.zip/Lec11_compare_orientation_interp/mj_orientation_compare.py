import mujoco as mj
from mujoco.glfw import glfw
import numpy as np
import utility as ram
from scipy.linalg import svd
import os

xml_path = 'three_blocks.xml' #xml file (assumes this is in the same folder as this file)
simend = 10 #simulation time
print_camera_config = 0 #set to 1 to print camera config
                        #this is useful for initializing view of the model)
print_model = 0 #set to 1 to print the model info in the file model.txt in the current location

# For callback functions
button_left = False
button_middle = False
button_right = False
lastx = 0
lasty = 0

def init_controller(model,data):
    #initialize the controller here. This function is called once, in the beginning
    pass

def controller(model, data):
    #put the controller here. This function is called inside the simulation.
    pass

def keyboard(window, key, scancode, act, mods):
    if act == glfw.PRESS and key == glfw.KEY_BACKSPACE:
        mj.mj_resetData(model, data)
        mj.mj_forward(model, data)

def mouse_button(window, button, act, mods):
    # update button state
    global button_left
    global button_middle
    global button_right

    button_left = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_LEFT) == glfw.PRESS)
    button_middle = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_MIDDLE) == glfw.PRESS)
    button_right = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_RIGHT) == glfw.PRESS)

    # update mouse position
    glfw.get_cursor_pos(window)

def mouse_move(window, xpos, ypos):
    # compute mouse displacement, save
    global lastx
    global lasty
    global button_left
    global button_middle
    global button_right

    dx = xpos - lastx
    dy = ypos - lasty
    lastx = xpos
    lasty = ypos

    # no buttons down: nothing to do
    if (not button_left) and (not button_middle) and (not button_right):
        return

    # get current window size
    width, height = glfw.get_window_size(window)

    # get shift key state
    PRESS_LEFT_SHIFT = glfw.get_key(
        window, glfw.KEY_LEFT_SHIFT) == glfw.PRESS
    PRESS_RIGHT_SHIFT = glfw.get_key(
        window, glfw.KEY_RIGHT_SHIFT) == glfw.PRESS
    mod_shift = (PRESS_LEFT_SHIFT or PRESS_RIGHT_SHIFT)

    # determine action based on mouse button
    if button_right:
        if mod_shift:
            action = mj.mjtMouse.mjMOUSE_MOVE_H
        else:
            action = mj.mjtMouse.mjMOUSE_MOVE_V
    elif button_left:
        if mod_shift:
            action = mj.mjtMouse.mjMOUSE_ROTATE_H
        else:
            action = mj.mjtMouse.mjMOUSE_ROTATE_V
    else:
        action = mj.mjtMouse.mjMOUSE_ZOOM

    mj.mjv_moveCamera(model, action, dx/height,
                      dy/height, scene, cam)

def scroll(window, xoffset, yoffset):
    action = mj.mjtMouse.mjMOUSE_ZOOM
    mj.mjv_moveCamera(model, action, 0.0, -0.05 *
                      yoffset, scene, cam)

#get the full path
dirname = os.path.dirname(__file__)
abspath = os.path.join(dirname + "/" + xml_path)
xml_path = abspath

#print the model
if (print_model==1):
    model_name = 'model.txt'
    model_path = os.path.join(dirname + "/" + model_name)
    mujoco.mj_printModel(model,model_path)


# MuJoCo data structures
model = mj.MjModel.from_xml_path(xml_path)  # MuJoCo model
data = mj.MjData(model)                # MuJoCo data
cam = mj.MjvCamera()                        # Abstract camera
opt = mj.MjvOption()                        # visualization options

# Init GLFW, create window, make OpenGL context current, request v-sync
glfw.init()
window = glfw.create_window(1200, 900, "Demo", None, None)
glfw.make_context_current(window)
glfw.swap_interval(1)

# initialize visualization data structures
mj.mjv_defaultCamera(cam)
mj.mjv_defaultOption(opt)
scene = mj.MjvScene(model, maxgeom=10000)
context = mj.MjrContext(model, mj.mjtFontScale.mjFONTSCALE_150.value)

# install GLFW mouse and keyboard callbacks
glfw.set_key_callback(window, keyboard)
glfw.set_cursor_pos_callback(window, mouse_move)
glfw.set_mouse_button_callback(window, mouse_button)
glfw.set_scroll_callback(window, scroll)

# Example on how to set camera configuration
# cam.azimuth = 90
# cam.elevation = -45
# cam.distance = 2
# cam.lookat = np.array([0.0, 0.0, 0])
cam.azimuth = 167.51316579483188 ; cam.elevation = -17.851038620913872 ; cam.distance =  1.3411372691758898
cam.lookat =np.array([ 0.0 , 0.0 , 0.0 ])

#initialize the controller
init_controller(model,data)

#set the controller
mj.set_mjcb_control(controller)

dt = 0.005
t_i = 2;
t_f = 5;
euler_i = np.array([0,0,0])
#Try these 4 cases
euler_f = np.array([np.pi/2,0,0]) #1: change in one angle, worksfine
#euler_f = np.array([np.pi/2,0,np.pi/2]) #2: works fine
#euler_f = np.array([np.pi/2,np.pi/3,np.pi/2]) #3: rotation has non-smooth interpolation even though it is normalized
#euler_f = np.array([np.pi/2,np.pi+0.5,np.pi/2]) #4: euler does not produce shortest path as it goes through singularity
quat_i = ram.euler2quat(euler_i)
quat_f = ram.euler2quat(euler_f)
rotation_i = ram.euler2rotation(euler_i)
rotation_f = ram.euler2rotation(euler_f)


pos1 = np.array([0,-0.4,0])
pos2 = np.array([0,0,0])
pos3 = np.array([0,0.4,0])
q_i = np.hstack((pos1,quat_i,pos2,quat_i,pos3,quat_i))
q = q_i.copy()

time_all = [];


def linear_interp(time,t0,tf,p0,pf):

    p = np.zeros(len(p0))

    for i in range(0,len(p)):
        if (time<t0):
            t = 0;
        elif(time>tf):
            t = 1
        else:
            t = (time-t0)/(tf-t0)

        p[i] = (1-t)*p0[i]+t*pf[i]

    return p


opt.frame = mj.mjtFrame.mjFRAME_BODY #or use 1 (check https://mujoco.readthedocs.io/en/latest/APIreference/APItypes.html#mjvoption)

while not glfw.window_should_close(window):
    time_prev = data.time

    while (data.time - time_prev < 1.0/60.0):

        data.time += dt

        euler = linear_interp(data.time,2,5,euler_i,euler_f)
        quat = ram.euler2quat(euler)
        q[3:7] = quat[:4].copy();

        quat = linear_interp(data.time,2,5,quat_i,quat_f)
        #normalize the quaternion
        quat = quat / np.linalg.norm(quat)
        q[10:14] = quat[:4].copy();

        #convert from (3,3) to (9,) for linear_interp
        rot_arr_i = rotation_i.flatten()  # or rotation_i.reshape(-1)
        rot_arr_f = rotation_f.flatten()  # or rotation_f.reshape(-1)
        rot_arr = linear_interp(data.time,2,5,rot_arr_i,rot_arr_f)
        #get rotation back to (3,3)
        rotation = rot_arr.reshape((3, 3))

        #normalizing the rotation matrix
        U, _, Vt = svd(rotation)
        R = U @ Vt
        if np.linalg.det(R) < 0: # Ensure right-handedness (determinant +1
            U[:, -1] *= -1
            R = U @ Vt
        #print(R@R.T)
        quat = ram.rotation2quat(R)
        q[17:21] = quat[:4].copy();


        data.qpos = q.copy()
        mj.mj_forward(model,data)



    if (data.time>=simend):
        break;

    # get framebuffer viewport
    viewport_width, viewport_height = glfw.get_framebuffer_size(
        window)
    viewport = mj.MjrRect(0, 0, viewport_width, viewport_height)

    #print camera configuration (help to initialize the view)
    if (print_camera_config==1):
        print('cam.azimuth =',cam.azimuth,';','cam.elevation =',cam.elevation,';','cam.distance = ',cam.distance)
        print('cam.lookat =np.array([',cam.lookat[0],',',cam.lookat[1],',',cam.lookat[2],'])')

    # Update scene and render
    mj.mjv_updateScene(model, data, opt, None, cam,
                       mj.mjtCatBit.mjCAT_ALL.value, scene)
    mj.mjr_render(viewport, scene, context)

    # swap OpenGL buffers (blocking call due to v-sync)
    glfw.swap_buffers(window)

    # process pending GUI events, call GLFW callbacks
    glfw.poll_events()

glfw.terminate()
